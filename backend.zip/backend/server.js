// server.js - Main Express Server for Admin Backend
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Environment variables
const SUPABASE_URL = process.env.REACT_APP_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.REACT_APP_SUPABASE_ANON_KEY;
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this';

// Initialize Supabase client
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"]
    }
  }
}));

app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://your-frontend-domain.com'] 
    : ['http://localhost:3000', 'http://127.0.0.1:3000', 'file://', '*'],
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 requests per windowMs
  message: {
    error: 'Too many login attempts, please try again later.',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
});

app.use('/api/', generalLimiter);

// JWT Authentication Middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Helper function to hash passwords
const hashPassword = async (password) => {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
};

// Helper function to verify passwords
const verifyPassword = async (password, hashedPassword) => {
  return await bcrypt.compare(password, hashedPassword);
};

// Routes

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({ 
    status: 'OK', 
    message: 'CLICARE Admin Backend is running',
    timestamp: new Date().toISOString()
  });
});

// Admin Login
app.post('/api/admin/login', loginLimiter, async (req, res) => {
  try {
    const { healthadminid, password } = req.body;

    // Input validation
    if (!healthadminid || !password) {
      return res.status(400).json({ 
        error: 'Admin ID and password are required' 
      });
    }

    // Query the admin from Supabase
    console.log('🔍 Looking for admin with ID:', healthadminid);
    
    const { data: adminData, error: adminError } = await supabase
      .from('healthAdmin')
      .select('*')
      .eq('healthadmin_id', healthadminid)  // Fixed: using healthadmin_id (with underscore)
      .single();

    console.log('Database query result:', { adminData, adminError });

    if (adminError || !adminData) {
      console.log('❌ Admin not found in database');
      return res.status(401).json({ 
        error: 'Invalid credentials' 
      });
    }

    console.log('✅ Admin found:', adminData.name);

    // Verify password (temporary plain text comparison for testing)
    console.log('Stored password:', adminData.password);
    console.log('Provided password:', password);
    
    let isValidPassword = false;
    
    // For now, just do plain text comparison since your DB has plain text passwords
    if (adminData.password === password) {
      isValidPassword = true;
      console.log('✅ Plain text password match');
    } else {
      // Try bcrypt comparison in case password is hashed
      try {
        isValidPassword = await verifyPassword(password, adminData.password);
        if (isValidPassword) {
          console.log('✅ Bcrypt password match');
        }
      } catch (error) {
        console.log('❌ Bcrypt comparison failed:', error.message);
      }
    }
    
    if (!isValidPassword) {
      return res.status(401).json({ 
        error: 'Invalid credentials' 
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { 
        id: adminData.id,
        healthadmin_id: adminData.healthadmin_id,  // Fixed: using healthadmin_id
        name: adminData.name,
        position: adminData.position
      },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    // Return success response (without password)
    const { password: _, ...adminInfo } = adminData;
    
    res.status(200).json({
      success: true,
      token,
      admin: adminInfo,
      message: 'Login successful'
    });

  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ 
      error: 'Internal server error during login' 
    });
  }
});

// Get Admin Profile
app.get('/api/admin/profile', authenticateToken, async (req, res) => {
  try {
    const { data: adminData, error } = await supabase
      .from('healthAdmin')
      .select('id, healthadmin_id, name, position')  // Fixed: using healthadmin_id
      .eq('id', req.user.id)
      .single();

    if (error || !adminData) {
      return res.status(404).json({ 
        error: 'Admin not found' 
      });
    }

    res.status(200).json({
      success: true,
      admin: adminData
    });

  } catch (error) {
    console.error('Get admin profile error:', error);
    res.status(500).json({ 
      error: 'Internal server error' 
    });
  }
});

// Dashboard Stats
app.get('/api/admin/dashboard-stats', authenticateToken, async (req, res) => {
  try {
    // Get patient counts
    const { data: outPatients, error: outError } = await supabase
      .from('outPatient')
      .select('id', { count: 'exact' });

    const { data: inPatients, error: inError } = await supabase
      .from('inPatient')
      .select('id', { count: 'exact' });

    const { data: appointments, error: appointError } = await supabase
      .from('appointments')
      .select('id', { count: 'exact' });

    if (outError || inError || appointError) {
      throw new Error('Database query error');
    }

    // Mock additional stats (you can extend these based on your actual tables)
    const stats = {
      totalPatients: (outPatients?.length || 0) + (inPatients?.length || 0),
      outPatients: outPatients?.length || 0,
      inPatients: inPatients?.length || 0,
      appointments: appointments?.length || 0,
      activeStaff: 12, // This would come from a staff table if you have one
      systemAlerts: 3
    };

    // Recent activities (mock data - you would get this from actual activity logs)
    const recentActivities = [
      {
        id: 1,
        time: '2 min',
        action: 'New patient registration',
        user: 'Dr. Sarah Johnson',
        status: 'success'
      },
      {
        id: 2,
        time: '5 min',
        action: 'Appointment scheduled',
        user: 'Nurse Mike Wilson',
        status: 'success'
      },
      {
        id: 3,
        time: '8 min',
        action: 'System backup completed',
        user: 'System',
        status: 'info'
      },
      {
        id: 4,
        time: '12 min',
        action: 'Lab results updated',
        user: 'Dr. Emily Chen',
        status: 'success'
      },
      {
        id: 5,
        time: '18 min',
        action: 'Equipment maintenance alert',
        user: 'System',
        status: 'warning'
      }
    ];

    // System status
    const systemStatus = {
      server: 'online',
      database: 'online',
      backup: 'completed'
    };

    res.status(200).json({
      success: true,
      stats,
      recentActivities,
      systemStatus
    });

  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ 
      error: 'Internal server error fetching dashboard data' 
    });
  }
});

// Get All Admins (for admin management)
app.get('/api/admin/all', authenticateToken, async (req, res) => {
  try {
    const { data: admins, error } = await supabase
      .from('healthAdmin')
      .select('id, healthadmin_id, name, position')  // Fixed: using healthadmin_id
      .order('name', { ascending: true });

    if (error) {
      throw error;
    }

    res.status(200).json({
      success: true,
      admins: admins || []
    });

  } catch (error) {
    console.error('Get all admins error:', error);
    res.status(500).json({ 
      error: 'Internal server error fetching admins' 
    });
  }
});

// Token validation endpoint
app.post('/api/admin/validate-token', authenticateToken, (req, res) => {
  res.status(200).json({
    success: true,
    valid: true,
    user: req.user
  });
});

// Admin logout (client-side token removal, but we can log it)
app.post('/api/admin/logout', authenticateToken, (req, res) => {
  // In a more complex setup, you might want to blacklist tokens
  res.status(200).json({
    success: true,
    message: 'Logged out successfully'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ 
    error: 'Something went wrong!' 
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ 
    error: 'Route not found' 
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 CLICARE Admin Backend running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 Supabase URL: ${SUPABASE_URL ? 'Connected' : 'Not configured'}`);
});

module.exports = app;